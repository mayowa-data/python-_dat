Car Sales Analysis using Python


```python
#import the necessary libraries

import pandas as pd
import numpy as ns
import matplotlib.pyplot as plt
import seaborn as sns

import  warnings
warnings.filterwarnings('ignore')
```


```python
# import the dataset

data = pd.read_csv("C:/Users/MAYOWA/Downloads/archive (25)/Car_sales.csv")

```


```python
# check the head of data

data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Manufacturer</th>
      <th>Model</th>
      <th>Sales_in_thousands</th>
      <th>__year_resale_value</th>
      <th>Vehicle_type</th>
      <th>Price_in_thousands</th>
      <th>Engine_size</th>
      <th>Horsepower</th>
      <th>Wheelbase</th>
      <th>Width</th>
      <th>Length</th>
      <th>Curb_weight</th>
      <th>Fuel_capacity</th>
      <th>Fuel_efficiency</th>
      <th>Latest_Launch</th>
      <th>Power_perf_factor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Acura</td>
      <td>Integra</td>
      <td>16.919</td>
      <td>16.360</td>
      <td>Passenger</td>
      <td>21.50</td>
      <td>1.8</td>
      <td>140.0</td>
      <td>101.2</td>
      <td>67.3</td>
      <td>172.4</td>
      <td>2.639</td>
      <td>13.2</td>
      <td>28.0</td>
      <td>2/2/2012</td>
      <td>58.280150</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Acura</td>
      <td>TL</td>
      <td>39.384</td>
      <td>19.875</td>
      <td>Passenger</td>
      <td>28.40</td>
      <td>3.2</td>
      <td>225.0</td>
      <td>108.1</td>
      <td>70.3</td>
      <td>192.9</td>
      <td>3.517</td>
      <td>17.2</td>
      <td>25.0</td>
      <td>6/3/2011</td>
      <td>91.370778</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Acura</td>
      <td>CL</td>
      <td>14.114</td>
      <td>18.225</td>
      <td>Passenger</td>
      <td>NaN</td>
      <td>3.2</td>
      <td>225.0</td>
      <td>106.9</td>
      <td>70.6</td>
      <td>192.0</td>
      <td>3.470</td>
      <td>17.2</td>
      <td>26.0</td>
      <td>1/4/2012</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Acura</td>
      <td>RL</td>
      <td>8.588</td>
      <td>29.725</td>
      <td>Passenger</td>
      <td>42.00</td>
      <td>3.5</td>
      <td>210.0</td>
      <td>114.6</td>
      <td>71.4</td>
      <td>196.6</td>
      <td>3.850</td>
      <td>18.0</td>
      <td>22.0</td>
      <td>3/10/2011</td>
      <td>91.389779</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Audi</td>
      <td>A4</td>
      <td>20.397</td>
      <td>22.255</td>
      <td>Passenger</td>
      <td>23.99</td>
      <td>1.8</td>
      <td>150.0</td>
      <td>102.6</td>
      <td>68.2</td>
      <td>178.0</td>
      <td>2.998</td>
      <td>16.4</td>
      <td>27.0</td>
      <td>10/8/2011</td>
      <td>62.777639</td>
    </tr>
  </tbody>
</table>
</div>




```python
#check the info of the data

data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 157 entries, 0 to 156
    Data columns (total 16 columns):
     #   Column               Non-Null Count  Dtype  
    ---  ------               --------------  -----  
     0   Manufacturer         157 non-null    object 
     1   Model                157 non-null    object 
     2   Sales_in_thousands   157 non-null    float64
     3   __year_resale_value  121 non-null    float64
     4   Vehicle_type         157 non-null    object 
     5   Price_in_thousands   155 non-null    float64
     6   Engine_size          156 non-null    float64
     7   Horsepower           156 non-null    float64
     8   Wheelbase            156 non-null    float64
     9   Width                156 non-null    float64
     10  Length               156 non-null    float64
     11  Curb_weight          155 non-null    float64
     12  Fuel_capacity        156 non-null    float64
     13  Fuel_efficiency      154 non-null    float64
     14  Latest_Launch        157 non-null    object 
     15  Power_perf_factor    155 non-null    float64
    dtypes: float64(12), object(4)
    memory usage: 19.8+ KB
    


```python
#check for duplication

data.nunique()
```




    Manufacturer            30
    Model                  156
    Sales_in_thousands     157
    __year_resale_value    117
    Vehicle_type             2
    Price_in_thousands     152
    Engine_size             31
    Horsepower              66
    Wheelbase               88
    Width                   78
    Length                 127
    Curb_weight            147
    Fuel_capacity           55
    Fuel_efficiency         20
    Latest_Launch          130
    Power_perf_factor      154
    dtype: int64




```python
# check for missing value

data.isnull().sum()
```




    Manufacturer            0
    Model                   0
    Sales_in_thousands      0
    __year_resale_value    36
    Vehicle_type            0
    Price_in_thousands      2
    Engine_size             1
    Horsepower              1
    Wheelbase               1
    Width                   1
    Length                  1
    Curb_weight             2
    Fuel_capacity           1
    Fuel_efficiency         3
    Latest_Launch           0
    Power_perf_factor       2
    dtype: int64




```python
# cal the percentage of the missing value

(data.isnull().sum()/(len(data)))*100
```




    Manufacturer            0.000000
    Model                   0.000000
    Sales_in_thousands      0.000000
    __year_resale_value    22.929936
    Vehicle_type            0.000000
    Price_in_thousands      1.273885
    Engine_size             0.636943
    Horsepower              0.636943
    Wheelbase               0.636943
    Width                   0.636943
    Length                  0.636943
    Curb_weight             1.273885
    Fuel_capacity           0.636943
    Fuel_efficiency         1.910828
    Latest_Launch           0.000000
    Power_perf_factor       1.273885
    dtype: float64




```python
# fill in the missing value
data['__year_resale_value'].fillna(data['__year_resale_value'].median(), inplace = True)

data['Price_in_thousands'].fillna(data['Price_in_thousands'].mean(), inplace = True)
data['Curb_weight'].fillna(data['Curb_weight'].mean(), inplace = True)
data['Fuel_efficiency'].fillna(data['Fuel_efficiency'].mean(), inplace = True)
data['Power_perf_factor'].fillna(data['Power_perf_factor'].mean(), inplace = True)


```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 157 entries, 0 to 156
    Data columns (total 16 columns):
     #   Column               Non-Null Count  Dtype  
    ---  ------               --------------  -----  
     0   Manufacturer         157 non-null    object 
     1   Model                157 non-null    object 
     2   Sales_in_thousands   157 non-null    float64
     3   __year_resale_value  157 non-null    float64
     4   Vehicle_type         157 non-null    object 
     5   Price_in_thousands   157 non-null    float64
     6   Engine_size          156 non-null    float64
     7   Horsepower           156 non-null    float64
     8   Wheelbase            156 non-null    float64
     9   Width                156 non-null    float64
     10  Length               156 non-null    float64
     11  Curb_weight          157 non-null    float64
     12  Fuel_capacity        156 non-null    float64
     13  Fuel_efficiency      157 non-null    float64
     14  Latest_Launch        157 non-null    object 
     15  Power_perf_factor    157 non-null    float64
    dtypes: float64(12), object(4)
    memory usage: 19.8+ KB
    


```python
# How many manufacturers 

data['Manufacturer'].value_counts()
```




    Dodge         11
    Ford          11
    Toyota         9
    Chevrolet      9
    Mercedes-B     9
    Mitsubishi     7
    Nissan         7
    Chrysler       7
    Volvo          6
    Oldsmobile     6
    Lexus          6
    Mercury        6
    Pontiac        6
    Volkswagen     6
    Saturn         5
    Cadillac       5
    Honda          5
    Plymouth       4
    Acura          4
    Buick          4
    Audi           3
    Jeep           3
    Porsche        3
    Hyundai        3
    BMW            3
    Lincoln        3
    Saab           2
    Subaru         2
    Jaguar         1
    Infiniti       1
    Name: Manufacturer, dtype: int64




```python
#Total Sale Distribution by manufacturer

sale = data.groupby('Manufacturer')['Sales_in_thousands'].sum().reset_index()

sales_data = sale.sort_values(by='Sales_in_thousands', ascending = False)

plt.figure(figsize = (12,8))

sns.barplot(x ='Sales_in_thousands', y = 'Manufacturer' , data = sales_data)
plt.title('Sales of car by manufacturer')
plt.xlabel('Sales in thousand')
```




    Text(0.5, 0, 'Sales in thousand')




    
![png](output_11_1.png)
    



```python
# distribution of car sales
prices = data['Sales_in_thousands']

plt.figure(figsize=(10, 6))
plt.hist(prices, bins=20, color='skyblue', edgecolor='black')
plt.title('Distribution of Car Prices')
plt.xlabel('Sales in thousand')
plt.ylabel('Frequency')
plt.show()
```


    
![png](output_12_0.png)
    



```python
#What is the distribution of the horsepower

data_py = data['Horsepower']

plt.figure(figsize=(10,6))
# sns.barplot(x='Horsepower', y='count', data=data_py)
plt.hist(data_py, bins=20, color='skyblue', edgecolor='black')
plt.title("Distribution of Horsepower");
plt.xlabel('Horsepower')
plt.ylabel('Count')
plt.show()
```


    
![png](output_13_0.png)
    



```python
#relationship btw horsepower and model

# Create a box plot
plt.figure(figsize=(12, 8))
sns.boxplot(x='Engine_size', y='Vehicle_type', data=data)
plt.xlabel('Engine_size')
plt.ylabel('Vehicle_type')
plt.title('Relationship between Horsepower and Model')
plt.show()
```


    
![png](output_14_0.png)
    



```python
# Fuel Capacity by Vehicle type

plt.figure(figsize=(10, 6))
sns.boxplot(x='Vehicle_type', y='Fuel_capacity', data=data[['Vehicle_type', 'Fuel_capacity', 'Fuel_efficiency']
                                                          ])
plt.title('Fuel Capacity by Vehicle Type')
plt.xlabel('Vehicle Type')
plt.ylabel('Fuel Capacity')
plt.show()
```


    
![png](output_15_0.png)
    

